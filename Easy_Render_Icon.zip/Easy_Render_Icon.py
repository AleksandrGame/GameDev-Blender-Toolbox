bl_info = {
    "name": "Render Icon",
    "blender": (4, 2, 0),
    "category": "Render",
    "description": "Render Icon"
}

import bpy
from bpy.props import IntProperty, StringProperty, BoolProperty, EnumProperty, IntProperty
from bpy.types import Operator, Panel

class EasyRenderIconProperties(bpy.types.PropertyGroup):
    resolution_x: IntProperty(
        name="Resolution X",
        description="Width of the icon",
        default=64,
        min=1,
        max=4096
    )
    resolution_y: IntProperty(
        name="Resolution Y",
        description="Height of the icon",
        default=64,
        min=1,
        max=4096
    )
    icon_name: StringProperty(
        name="Icon Name",
        description="Name of the rendered icon",
        default="New Icon"
    )
    save_path: StringProperty(
        name="Save Path",
        description="Path to save the rendered icon",
        default="",
        subtype='DIR_PATH'
    )
    transparent_background: BoolProperty(
        name="Transparent Background",
        description="Enable transparent background for the render",
        default=False
    )
    file_format: EnumProperty(
        name="File Format",
        description="Format to save the rendered image",
        items=[
            ('PNG', "PNG", "Save as PNG format"),
            ('JPEG', "JPEG", "Save as JPEG format"),
            ('OPEN_EXR', "OpenEXR", "Save as OpenEXR format")
        ],
        default='PNG'
    )
    jpeg_quality: IntProperty(
        name="JPEG Quality",
        description="Quality of the JPEG file",
        default=90,
        min=1,
        max=100
    )

class RENDER_OT_EasyRenderIcon(Operator):
    bl_idname = "render.easy_render_icon"
    bl_label = "Easy Render Icon"
    bl_description = "Render the icon with the specified settings"

    @classmethod
    def poll(cls, context):
        return context.scene.camera is not None

    def execute(self, context):
        props = context.scene.easy_render_icon_props
        
        # Set render resolution
        context.scene.render.resolution_x = props.resolution_x
        context.scene.render.resolution_y = props.resolution_y
        context.scene.render.resolution_percentage = 100

        # Set transparent background if enabled
        if props.transparent_background:
            context.scene.render.film_transparent = True
        else:
            context.scene.render.film_transparent = False

        # Render image in the Image Editor
        bpy.ops.render.render('INVOKE_DEFAULT')
        return {'FINISHED'}

class RENDER_OT_SaveEasyRenderIcon(Operator):
    bl_idname = "render.save_easy_render_icon"
    bl_label = "Save Easy Render Icon"
    bl_description = "Save the rendered icon to the specified path"

    @classmethod
    def poll(cls, context):
        props = context.scene.easy_render_icon_props
        has_render_result = bpy.data.images.get("Render Result")
        return bool(props.save_path) and has_render_result and has_render_result.has_data

    def execute(self, context):
        props = context.scene.easy_render_icon_props
        filepath = bpy.path.abspath(f"{props.save_path}/{props.icon_name}")

        # Set file extension and save options
        if props.file_format == 'PNG':
            filepath += ".png"
            bpy.data.images["Render Result"].save_render(filepath)
        elif props.file_format == 'JPEG':
            filepath += ".jpg"
            bpy.data.images["Render Result"].save_render(filepath, quality=props.jpeg_quality)
        elif props.file_format == 'OPEN_EXR':
            filepath += ".exr"
            bpy.data.images["Render Result"].save_render(filepath)

        self.report({'INFO'}, f"Icon saved to {filepath}")
        return {'FINISHED'}

class RENDER_PT_EasyRenderIconPanel(Panel):
    bl_label = "Easy Render Icon"
    bl_idname = "RENDER_PT_easy_render_icon_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Easy Render Icon"

    def draw(self, context):
        layout = self.layout
        props = context.scene.easy_render_icon_props

        layout.prop(props, "resolution_x")
        layout.prop(props, "resolution_y")
        layout.prop(props, "icon_name")
        layout.prop(props, "save_path")
        layout.prop(props, "transparent_background")
        layout.prop(props, "file_format")

        if props.file_format == 'JPEG':
            layout.prop(props, "jpeg_quality")

        render_row = layout.row()
        render_row.enabled = context.scene.camera is not None
        render_row.operator("render.easy_render_icon", text="Render Icon")

        save_icon_row = layout.row()
        has_render_result = bpy.data.images.get("Render Result")
        save_icon_row.enabled = has_render_result is not None and has_render_result.has_data and bool(props.save_path)
        save_icon_row.operator("render.save_easy_render_icon", text="Save Icon")

classes = (
    EasyRenderIconProperties,
    RENDER_OT_EasyRenderIcon,
    RENDER_OT_SaveEasyRenderIcon,
    RENDER_PT_EasyRenderIconPanel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.easy_render_icon_props = bpy.props.PointerProperty(
        type=EasyRenderIconProperties
    )

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.easy_render_icon_props

if __name__ == "__main__":
    register()
