import bpy
from . import operators, panels, rigs, AnimationExport  # Подключаем новый модуль

bl_info = {
    "name": "UEAssistant",
    "blender": (4, 2, 0),
    "category": "Scene",
    "description": "Tools to assist with Unreal Engine workflows. This addon provides features for easier animation export to Unreal Engine, including automatic setup of export presets.",
    "author": "Aleksandr Steblak",
    "version": (1, 0, 0),
    "support": "COMMUNITY",
    "wiki_url": "https://your-addon-wiki.com",  # (опционально, если есть документация)
    "tracker_url": "https://your-addon-bug-tracker.com",  # (опционально, если есть)
}


def register():
    operators.register()
    panels.register()
    rigs.register()
    AnimationExport.register()  # Регистрируем модуль экспорта анимации

def unregister():
    operators.unregister()
    panels.unregister()
    rigs.unregister()
    AnimationExport.unregister()  # Отменяем регистрацию модуля

if __name__ == "__main__":
    register()
