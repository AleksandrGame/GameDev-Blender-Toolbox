import bpy
import os


def find_templates_in_directory():
    """
    Поиск всех .blend файлов в папке rigs относительно директории аддона.
    Возвращает список имен файлов.
    """
    addon_dir = os.path.dirname(__file__)
    rigs_dir = os.path.normpath(os.path.join(addon_dir, "rigs"))
    if not os.path.exists(rigs_dir):
        print("Directory 'rigs' not found!")
        return []
    return [f for f in os.listdir(rigs_dir) if f.endswith('.blend')]


def import_collection(filepath, collection_name):
    """
    Импортирует коллекцию из другого .blend файла, если она ещё не существует в сцене.
    """
    if collection_name in bpy.data.collections:
        print(f"Collection '{collection_name}' already exists, skipping import.")
        return None

    with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
        if collection_name in data_from.collections:
            data_to.collections = [collection_name]
        else:
            return None

    imported_collection = bpy.data.collections.get(collection_name)
    return imported_collection


class ImportRigTemplateOperator(bpy.types.Operator):
    """Оператор для импорта выбранного темплейта"""
    bl_idname = "rig.import_template"
    bl_label = "Import Rig Template"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(name="Filepath")

    def execute(self, context):
        if not self.filepath:
            self.report({'WARNING'}, "Filepath is empty.")
            return {'CANCELLED'}

        filepath = os.path.normpath(self.filepath)
        if not os.path.exists(filepath):
            self.report({'WARNING'}, f"File not found: {filepath}")
            return {'CANCELLED'}

        try:
            # Получаем список коллекций из файла
            with bpy.data.libraries.load(filepath, link=False) as (data_from, _):
                collections_to_import = data_from.collections

            imported_collections = []
            for collection_name in collections_to_import:
                # Проверяем и импортируем только те коллекции, которых ещё нет
                imported_collection = import_collection(filepath, collection_name)
                if imported_collection:
                    context.scene.collection.children.link(imported_collection)
                    imported_collections.append(imported_collection)
                    print(f"Imported collection: {imported_collection.name}")

            if not imported_collections:
                self.report({'INFO'}, "No new collections were imported (all duplicates skipped).")
            else:
                self.report({'INFO'}, f"Imported {len(imported_collections)} new collections.")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import template: {str(e)}")
            return {'CANCELLED'}

        return {'FINISHED'}


def update_template_list(self, context):
    """
    Функция для динамического обновления списка темплейтов.
    """
    addon_dir = os.path.dirname(__file__)
    rigs_dir = os.path.normpath(os.path.join(addon_dir, "rigs"))
    templates = find_templates_in_directory()
    return [
        (os.path.join(rigs_dir, template), template, "")
        for template in templates
    ]


def register():
    bpy.utils.register_class(ImportRigTemplateOperator)

    # Привязка пользовательских свойств
    bpy.types.Scene.ueassistant_template_list = bpy.props.EnumProperty(
        name="Template List",
        description="Available Rig Templates",
        items=update_template_list
    )


def unregister():
    bpy.utils.unregister_class(ImportRigTemplateOperator)

    # Удаление пользовательских свойств
    del bpy.types.Scene.ueassistant_template_list
