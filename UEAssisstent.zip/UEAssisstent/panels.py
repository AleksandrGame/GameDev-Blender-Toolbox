import bpy

class UEAssistantPanel(bpy.types.Panel):
    """Main Panel for UEAssistant Tools"""
    bl_label = "UEAssistant Tools"
    bl_idname = "VIEW3D_PT_ueassistant_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'UEAssistant'

    def draw(self, context):
        layout = self.layout

        # Секция для настроек сцены
        layout.label(text="Scene Setup:")
        layout.operator("scene.set_ue_units", text="Set UE Scene Units")
        layout.operator("scene.clear_scene", text="Clear Scene")


class RigTemplatesPanel(bpy.types.Panel):
    """Panel for Rig Templates"""
    bl_label = "Rig Templates"
    bl_idname = "VIEW3D_PT_ueassistant_templates"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'UEAssistant'

    def draw(self, context):
        layout = self.layout

        # Секция для работы с темплейтами
        layout.label(text="Available Templates:")
        
        # Выпадающий список
        layout.prop(context.scene, "ueassistant_template_list", text="Select Template")
        
        # Кнопка для импорта
        layout.operator("rig.import_template", text="Import Template").filepath = context.scene.ueassistant_template_list


class AnimationExportPanel(bpy.types.Panel):
    """Panel for Exporting Animations"""
    bl_label = "Export Animation"
    bl_idname = "VIEW3D_PT_ueassistant_animation_export"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'UEAssistant'

    def draw(self, context):
        layout = self.layout

        # Кнопка для экспорта анимации
        layout.operator("export.animation_with_preset", text="Export Animation")


def register():
    bpy.utils.register_class(UEAssistantPanel)
    bpy.utils.register_class(RigTemplatesPanel)
    bpy.utils.register_class(AnimationExportPanel)


def unregister():
    bpy.utils.unregister_class(UEAssistantPanel)
    bpy.utils.unregister_class(RigTemplatesPanel)
    bpy.utils.unregister_class(AnimationExportPanel)
