import bpy
import os

class ExportAnimationWithPresetOperator(bpy.types.Operator):
    """Open Export Dialog with Preset for UE"""
    bl_idname = "export.animation_with_preset"
    bl_label = "Export Active Animation with Preset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Проверяем наличие активного объекта и экшна
        obj = context.active_object
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Active object must be an armature")
            return {'CANCELLED'}

        # Получаем текущую анимацию
        action = obj.animation_data.action if obj.animation_data else None
        if not action:
            self.report({'ERROR'}, "No active animation found on the armature")
            return {'CANCELLED'}

        # Имя анимации из текущего Action
        animation_name = action.name
        export_path = bpy.path.abspath("//exports/")
        os.makedirs(export_path, exist_ok=True)

        # Полный путь для сохранения файла
        export_file = os.path.join(export_path, f"{animation_name}.fbx")

        # Сохраняем текущие настройки экспорта для восстановления после открытия окна
        prefs = context.preferences
        scene = context.scene

        # Открываем стандартное окно экспорта с параметрами
        bpy.ops.export_scene.fbx('INVOKE_DEFAULT', 
                                 filepath=export_file,
                                 use_selection=True,                     # Только выделенные объекты
                                 bake_anim=True,                         # Выпекать анимацию
                                 bake_anim_use_all_actions=False,        # Только текущая анимация
                                 add_leaf_bones=False,                   # Убрать лишние кости
                                 primary_bone_axis='Y',                  # Ось Y как основная
                                 secondary_bone_axis='X',                # Ось X как вторичная
                                 object_types={'ARMATURE', 'MESH'},      # Экспортировать только скелеты и меши
                                 use_armature_deform_only=True,          # Только используемые модификаторы
                                 bake_anim_use_nla_strips=False,         # Отключаем экспорт NLA Strips
                                 bake_anim_simplify_factor=0.0)          # Без упрощения ключей

        self.report({'INFO'}, f"Ready to export animation '{animation_name}'")
        return {'FINISHED'}


# Регистрация классов
def register():
    bpy.utils.register_class(ExportAnimationWithPresetOperator)


def unregister():
    bpy.utils.unregister_class(ExportAnimationWithPresetOperator)
