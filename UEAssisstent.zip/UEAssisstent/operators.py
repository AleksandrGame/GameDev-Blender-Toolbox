import bpy

class SetSceneUnitsOperator(bpy.types.Operator):
    """Set scene units for Unreal Engine (1 unit = 1 cm)"""
    bl_idname = "scene.set_ue_units"
    bl_label = "Set UE Scene Units"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Set metric system with scale for UE
        scene = context.scene
        scene.unit_settings.system = 'METRIC'
        scene.unit_settings.system_rotation = 'DEGREES'
        scene.unit_settings.scale_length = 0.01

        # Update view clipping settings for all 3D viewports
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.clip_start = 0.01
                        space.clip_end = 10000

        self.report({'INFO'}, "Scene units and view clipping updated for Unreal Engine!")
        return {'FINISHED'}


class ClearSceneOperator(bpy.types.Operator):
    """Clear all objects and collections from the scene"""
    bl_idname = "scene.clear_scene"
    bl_label = "Clear Scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Select and delete all objects
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.delete()

        # Remove all collections
        for collection in list(bpy.data.collections):
            bpy.data.collections.remove(collection)

        # Clear unused data (optional)
        bpy.ops.outliner.orphans_purge()

        self.report({'INFO'}, "Scene cleared!")
        return {'FINISHED'}


def register():
    bpy.utils.register_class(SetSceneUnitsOperator)
    bpy.utils.register_class(ClearSceneOperator)


def unregister():
    bpy.utils.unregister_class(SetSceneUnitsOperator)
    bpy.utils.unregister_class(ClearSceneOperator)
