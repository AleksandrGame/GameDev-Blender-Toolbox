bl_info = {
    "name": "Material Texture Editor",
    "blender": (4, 2, 0),
    "category": "Material",
    "description": "Allows editing material textures directly in the N Panel for selected models."
}

import bpy

class MATERIAL_PT_TextureEditorPanel(bpy.types.Panel):
    bl_label = "Material Texture Editor"
    bl_idname = "MATERIAL_PT_texture_editor"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Material Editor"

    def draw(self, context):
        layout = self.layout
        obj = context.object

        if obj and obj.type == 'MESH':
            layout.label(text="Selected Model: " + obj.name)
            layout.label(text="Materials:")

            layout.prop_search(context.scene, "selected_material_name", bpy.data, "materials", text="Material")

            if context.scene.selected_material_name:
                mat = bpy.data.materials.get(context.scene.selected_material_name)
                if mat:
                    layout.label(text=f"Editing Material: {mat.name}")

                    layout.prop(context.scene, "texture_type", text="Texture Type")
                    layout.operator("material.add_texture", text="Add Texture")

                    for node in mat.node_tree.nodes:
                        if node.type == 'TEX_IMAGE':
                            box = layout.box()
                            box.label(text=f"Texture: {node.label}")
                            box.prop(node, "image", text="")
                            box.operator("material.open_image", text="").node_name = node.name
                            box.prop(node.image.colorspace_settings, "name", text="Color Space")
                            box.operator("material.remove_texture", text="Remove").node_name = node.name

        else:
            layout.label(text="Select a mesh object to edit materials.")

class MATERIAL_OT_AddTexture(bpy.types.Operator):
    bl_label = "Add Texture"
    bl_idname = "material.add_texture"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        mat_name = context.scene.selected_material_name
        material = bpy.data.materials.get(mat_name)

        if material and material.use_nodes:
            node_tree = material.node_tree

            # Check for duplicate texture types
            for node in node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.label == context.scene.texture_type:
                    self.report({'WARNING'}, f"{context.scene.texture_type} texture already exists.")
                    return {'CANCELLED'}

            tex_node = node_tree.nodes.new('ShaderNodeTexImage')
            tex_node.label = context.scene.texture_type
            tex_node.location = (-300, 300)

            # Load selected image
            if self.filepath:
                image = bpy.data.images.load(self.filepath)
                tex_node.image = image

            # Automatically connect texture based on type
            if context.scene.texture_type == 'BASE_COLOR':
                for node in node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        node_tree.links.new(tex_node.outputs['Color'], node.inputs['Base Color'])
                        break

            elif context.scene.texture_type == 'NORMAL':
                normal_node = node_tree.nodes.new('ShaderNodeNormalMap')
                normal_node.location = (-100, 300)
                node_tree.links.new(tex_node.outputs['Color'], normal_node.inputs['Color'])
                for node in node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        node_tree.links.new(normal_node.outputs['Normal'], node.inputs['Normal'])
                        break

            elif context.scene.texture_type == 'MASK':
                separate_node = node_tree.nodes.new('ShaderNodeSeparateRGB')
                separate_node.location = (-100, 300)
                node_tree.links.new(tex_node.outputs['Color'], separate_node.inputs['Image'])
                for node in node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        node_tree.links.new(separate_node.outputs['G'], node.inputs['Roughness'])
                        node_tree.links.new(separate_node.outputs['B'], node.inputs['Metallic'])
                        break

            elif context.scene.texture_type == 'ROUGHNESS':
                for node in node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        node_tree.links.new(tex_node.outputs['Color'], node.inputs['Roughness'])
                        break

            elif context.scene.texture_type == 'METALLIC':
                for node in node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        node_tree.links.new(tex_node.outputs['Color'], node.inputs['Metallic'])
                        break

            elif context.scene.texture_type == 'OPACITY':
                for node in node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        node_tree.links.new(tex_node.outputs['Color'], node.inputs['Alpha'])
                        break

            elif context.scene.texture_type == 'SPECULAR':
                for node in node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        node_tree.links.new(tex_node.outputs['Color'], node.inputs['Specular'])
                        break

            # Set Color Space
            tex_node.image.colorspace_settings.name = 'Non-Color' if context.scene.texture_color_space == 'NON_COLOR' else 'sRGB'

        return {'FINISHED'}

class MATERIAL_OT_RemoveTexture(bpy.types.Operator):
    bl_label = "Remove Texture"
    bl_idname = "material.remove_texture"

    node_name: bpy.props.StringProperty()

    def execute(self, context):
        mat_name = context.scene.selected_material_name
        material = bpy.data.materials.get(mat_name)

        if material and material.use_nodes:
            node_tree = material.node_tree
            node = node_tree.nodes.get(self.node_name)
            if node:
                node_tree.nodes.remove(node)

        return {'FINISHED'}

class MATERIAL_OT_OpenImage(bpy.types.Operator):
    bl_label = "Open Image"
    bl_idname = "material.open_image"

    node_name: bpy.props.StringProperty()

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        mat_name = context.scene.selected_material_name
        material = bpy.data.materials.get(mat_name)

        if material and material.use_nodes:
            node_tree = material.node_tree
            node = node_tree.nodes.get(self.node_name)
            if node and node.type == 'TEX_IMAGE':
                image = bpy.data.images.load(self.filepath)
                node.image = image

        return {'FINISHED'}

def register():
    bpy.utils.register_class(MATERIAL_PT_TextureEditorPanel)
    bpy.utils.register_class(MATERIAL_OT_AddTexture)
    bpy.utils.register_class(MATERIAL_OT_RemoveTexture)
    bpy.utils.register_class(MATERIAL_OT_OpenImage)
    bpy.types.Scene.selected_material_name = bpy.props.StringProperty()
    bpy.types.Scene.texture_type = bpy.props.EnumProperty(
        name="Texture Type",
        description="Select the type of texture to add",
        items=[
            ('BASE_COLOR', "Base Color", "Connect to Base Color"),
            ('NORMAL', "Normal", "Connect as Normal Map"),
            ('MASK', "Mask", "Connect to Metallic and Roughness"),
            ('ROUGHNESS', "Roughness", "Connect to Roughness"),
            ('METALLIC', "Metallic", "Connect to Metallic"),
            ('OPACITY', "Opacity", "Connect to Opacity"),
            ('SPECULAR', "Specular", "Connect to Specular")
        ],
        default='BASE_COLOR'
    )
    bpy.types.Scene.texture_color_space = bpy.props.EnumProperty(
        name="Color Space",
        description="Set the color space of the texture",
        items=[
            ('SRGB', "sRGB", "Use sRGB color space"),
            ('NON_COLOR', "Non-Color", "Use Non-Color data")
        ],
        default='SRGB'
    )

def unregister():
    bpy.utils.unregister_class(MATERIAL_PT_TextureEditorPanel)
    bpy.utils.unregister_class(MATERIAL_OT_AddTexture)
    bpy.utils.unregister_class(MATERIAL_OT_RemoveTexture)
    bpy.utils.unregister_class(MATERIAL_OT_OpenImage)
    del bpy.types.Scene.selected_material_name
    del bpy.types.Scene.texture_type
    del bpy.types.Scene.texture_color_space

if __name__ == "__main__":
    register()
